<?php
    $nome=$_POST["email"];
    echo "<script>alert('Formulário Foi enviado')</script>";
